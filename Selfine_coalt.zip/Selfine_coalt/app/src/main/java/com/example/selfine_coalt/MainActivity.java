package com.example.selfine_coalt;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button button,button1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button);
        button1 = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchActivities();
            }

            private void switchActivities() {

                Intent switchActivityIntent = new Intent(MainActivity.this,signup.class);
                startActivity(switchActivityIntent);

            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchActivities1();
            }

            private void switchActivities1() {
                Intent switchActivityIntent1 = new Intent(MainActivity.this,login.class);
                startActivity(switchActivityIntent1);
            }
        });


    }
}