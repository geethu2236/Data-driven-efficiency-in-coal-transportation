package com.example.selfine_coalt;

public class users {
    String city1;
    String phoneno;
    String Name;

    public users(String city1, String phoneno, String name) {

        this.city1 = city1;
        this.phoneno = phoneno;
        Name = name;
    }

    public String getCity1() {
        return city1;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public String getName() {
        return Name;
    }
}
