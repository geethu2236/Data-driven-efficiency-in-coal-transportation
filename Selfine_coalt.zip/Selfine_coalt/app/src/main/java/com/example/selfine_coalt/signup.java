package com.example.selfine_coalt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signup extends AppCompatActivity {
    private FirebaseAuth auth;
    private EditText signupEmail, signupPassword, city, phone,name;
    private Button signupButton;

    DatabaseReference UsersDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        auth = FirebaseAuth.getInstance();
        signupEmail = findViewById(R.id.mail);
        signupPassword = findViewById(R.id.pass);
        city = findViewById(R.id.City);
        phone = findViewById(R.id.phone);
        name=findViewById(R.id.name);
        signupButton = findViewById(R.id.signup);
        UsersDB = FirebaseDatabase.getInstance().getReference().child("Users");

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = signupEmail.getText().toString().trim();
                String pass = signupPassword.getText().toString().trim();
                String userName = name.getText().toString().trim();
                String userPhone = phone.getText().toString().trim();
                String userCity = city.getText().toString().trim();
                if (user.isEmpty()) {
                    signupEmail.setError("Email cannot be empty");
                }
                if (pass.isEmpty()) {
                    signupPassword.setError("Password cannot be empty");
                }
                if (userName.isEmpty()) {
                    name.setError("Name cannot be empty");
                }if (userPhone.isEmpty()) {
                    phone.setError("Phone cannot be empty");
                } if (userCity.isEmpty()) {
                    city.setError("City cannot be empty");
                }
                else {
                    auth.createUserWithEmailAndPassword(user, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(signup.this, "SignUp Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(signup.this, home.class));
                            } else {
                                Toast.makeText(signup.this, "SignUp Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
                insertUsersdata(); // Move this line inside the onClick method if you want to insert data after successful authentication.
            }
        });


    }
    private void insertUsersdata() {
        String phoneno = phone.getText().toString();
        String city1 = city.getText().toString();
        String Name = name.getText().toString();

        if (!phoneno.isEmpty() && !city1.isEmpty() && !Name.isEmpty()) {
            users user = new users(phoneno, city1, Name);
            UsersDB.push().setValue(user);
            Toast.makeText(signup.this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(signup.this, "All fields must be filled", Toast.LENGTH_SHORT).show();
        }

    }


}
